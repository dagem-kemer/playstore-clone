export default function Demo() {
  return (
    <div>
      <p>App detail</p>
    </div>
  );
}
